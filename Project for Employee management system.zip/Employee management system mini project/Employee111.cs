﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Project
{
    class Employee111
    {

        public int deptID, empID;
        public long phone;
        public string Empname, email;
        public Employee111()
        {
            Console.WriteLine("Enter the employee department ID : ");
            deptID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the employee ID : ");
            empID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the employee Name : ");
            Empname = Console.ReadLine();
            Console.WriteLine("Enter the employee email :");
            email = Console.ReadLine();
            Console.WriteLine("Enter the employee phone number : ");
            phone = long.Parse(Console.ReadLine());

        }
        public string print1()
        {
            return (deptID.ToString().PadLeft(20) + " | " + empID.ToString().PadLeft(20) + "|" + Empname.PadLeft(20) + "|" + email.PadLeft(20) + "|" + phone.ToString().PadLeft(20));
        }
    }
}
